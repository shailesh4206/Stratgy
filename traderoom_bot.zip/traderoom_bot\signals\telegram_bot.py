# signals/telegram_bot.py — HIGH WIN RATE VERSION (Production-hardened)
import asyncio
import random
import aiohttp
from datetime import datetime
from utils.logger import setup_logger, sanitize_text

logger = setup_logger("telegram")


def _escape_markdown_v2(text: str) -> str:
    # Telegram MarkdownV2 special chars: _ * [ ] ( ) ~ ` > # + - = | { } . !
    if text is None:
        return ""
    s = str(text)
    for ch in ['\\', '_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']:
        s = s.replace(ch, f"\\{ch}")
    return s


class TelegramBot:

    def __init__(self, config, http_client):
        self.config = config
        self.token = config.TELEGRAM_BOT_TOKEN
        self.chat_id = config.TELEGRAM_CHAT_ID
        self.base = f"https://api.telegram.org/bot{self.token}"

        self._http = http_client
        self._timeout = aiohttp.ClientTimeout(total=15)
        self._max_retries = 5



    async def close(self) -> None:
        # Shared HttpClient is closed by main().
        return


    async def send_message(self, text, parse_mode="MarkdownV2") -> bool:
        """Crash-proof Telegram sender.

        Returns False on any failure; never raises.
        """
        try:
            if not self.token or self.token == "YOUR_TOKEN_HERE":
                logger.error(
                    "Telegram token missing/placeholder. Set TELEGRAM_TOKEN or TELEGRAM_BOT_TOKEN in .env"
                )
                return False
            if not self.chat_id or self.chat_id == "YOUR_CHAT_ID_HERE":
                logger.error(
                    "Telegram chat_id missing/placeholder. Set TELEGRAM_CHAT_ID in .env"
                )
                return False


            # Telegram MarkdownV2: escape user-generated text.
            safe_text = sanitize_text(text, replace_emojis=False)
            if parse_mode == "MarkdownV2":
                safe_text = _escape_markdown_v2(safe_text)

            payload = {
                "chat_id": str(self.chat_id),
                "text": safe_text,
                "parse_mode": parse_mode,
                "disable_web_page_preview": True,
            }



            # Defensive validation: Telegram rejects empty/whitespace-only text.
            if safe_text is None:
                logger.error("Telegram send_message: message text is None")
                return False
            if isinstance(safe_text, str):
                _trim = safe_text.strip()
                if not _trim:
                    logger.error(
                        "Telegram send_message: message text is empty/whitespace. len={} source={}".format(
                            len(safe_text), type(text).__name__
                        )
                    )
                    return False
            else:
                # Extremely defensive
                logger.error(f"Telegram send_message: message text not str type={type(safe_text)}")
                return False

            for attempt in range(self._max_retries):
                try:
                    # NOTE: Telegram expects form-urlencoded or JSON. We send JSON payload.
                    # HttpClient.request_json doesn't support json body, so we must send via params.
                    # Workaround: encode payload into params for aiohttp request.
                    resp_json = await self._http.request_json(
                        f"{self.base}/sendMessage",
                        params={
                            k: ("true" if v is True else "false" if v is False else v)
                            for k, v in payload.items()
                        },
                        method="POST",


                        timeout=self._timeout,
                        headers=None,
                        expected_status=(200,),
                        log_ctx=f"telegram/sendMessage attempt={attempt+1}",
                    )
                    if not resp_json:
                        return False
                    ok = bool(resp_json.get("ok", False))
                    if not ok:
                        logger.error(f"Telegram sendMessage rejected: resp={resp_json}")
                    return ok


                except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                    wait_s = (2 ** attempt) + random.random()
                    logger.warning(
                        f"Telegram send attempt {attempt+1}/{self._max_retries} failed: {e}. Backoff {wait_s:.1f}s"
                    )
                    await asyncio.sleep(wait_s)

            return False
        except Exception as e:
            # Telegram must NEVER crash the bot.
            logger.error(f"Telegram send_message crashed: {e}")
            return False



    def _bar(self, pct, w=10):
        pct=max(0,min(100,pct)); f=int(pct/(100/w))
        return "█"*f+"░"*(w-f)

    def _danger(self, pct):
        # Use text instead of emoji to avoid Markdown parsing issues.
        if pct >= 75:
            return "[RED]"
        if pct >= 50:
            return "[YELLOW]"
        return "[GREEN]"


    def _format_signal(self, sig):
        # Defensive formatting: Telegram must never crash the bot.
        try:
            lvl = sig.get("levels", {})
            tr  = sig.get("tr", {})
            d   = sig.get("direction", "NONE")
            sym = sig.get("symbol", "UNKNOWN")
        except Exception:
            return "Signal formatting error — invalid signal payload"

        px = sig.get("price", 0)

        arrow  ="📈" if d=="LONG" else "📉"

        action ="🟢 LONG  — BUY" if d=="LONG" else "🔴 SHORT — SELL"
        when   ="dips to entry zone" if d=="LONG" else "rises to entry zone"
        sl_dir ="BELOW" if d=="LONG" else "ABOVE"

        pb = self._bar(tr.get("profit_pct", 0))
        dlb = self._bar(tr.get("daily_pct", 0))
        tlb = self._bar(tr.get("total_pct", 0))
        dc = self._danger(tr.get("daily_pct", 0))
        tc = self._danger(tr.get("total_pct", 0))


        # Win rate booster summary
        adx_str  = sig.get("adx_strength","?")
        adx_val  = sig.get("adx",0)
        obv_sig  = sig.get("obv_signal","?")
        fib_ok   = "✅" if sig.get("at_fib") else "⚪"
        fib_lv   = sig.get("fib_level","—")
        candle   = sig.get("candle","NONE")
        regime   = sig.get("regime","?")
        fr_pct   = sig.get("funding_rate",0)
        fr_bias  = sig.get("funding_bias","NEUTRAL")
        session  = sig.get("session","?")

        warns=""
        if tr["warnings"]:
            warns="\n"+ "\n".join([f"  ⚠️ {w}" for w in tr["warnings"]])+"\n"

        top_reasons="\n".join([f"  {r}" for r in sig["reasons"][:6]])

        msg=f"""
{arrow} *SIGNAL — {sym}*
{action}  |  Stage: `{tr['stage']}`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Quality: `{sig['quality']}`  Confidence: `{sig['confidence']}%`

📍 *ENTRY ZONE*
  `${lvl['entry_low']:,.2f}` → `${lvl['entry_high']:,.2f}`
  _(Wait for price to {when})_

🛑 *STOP LOSS:* `${lvl['stop_loss']:,.2f}`
  _(Exit if candle closes {sl_dir} this)_

🎯 *TAKE PROFIT*
  TP1 `${lvl['target_1']:,.2f}` — close `30%`
  TP2 `${lvl['target_2']:,.2f}` — close `50%`
  TP3 `${lvl['target_3']:,.2f}` — trail `20%`

⚖️ *Risk/Reward:* `1:{lvl['risk_reward']}`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔬 *WIN RATE BOOSTERS*
  ADX:    `{adx_val:.0f}` ({adx_str}) — trend strength
  OBV:    `{obv_sig}` — volume direction
  Fib:    {fib_ok} level `{fib_lv}` — institutional zone
  Candle: `{candle}` — entry pattern
  Regime: `{regime}` — market condition
  Session:`{session}`
  Funding:`{fr_pct:.4f}%` ({fr_bias})
  RSI:    `{sig['rsi']:.0f}`  Vol: `{sig['rel_volume']:.1f}x`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 *POSITION SIZE*
  Risk this trade: `$15` (0.3%)
  Estimated profit @ TP2: `~${tr['profit_est']:.0f}`
  Trade #{tr['trades_today']} today  |  ID: `{sig.get('trade_id','—')}`
{warns}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 *ACCOUNT STATUS*
🎯 `{pb}` `{tr['profit_pct']:.0f}%` — `${tr['profit_made']}`/`${tr['target']}`
{dc} Daily `{dlb}` `${tr['daily_loss']}`/`$100` (`${tr['daily_remaining']}` left)
{tc} Total `{tlb}` `${tr['total_loss']}`/`$200`
📅 Trading days: `{tr['trading_days']}`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 *CONFLUENCE REASONS*
{top_reasons}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ _Signal only — YOU place the trade_
⚠️ _Risk max $15 — never more_
⚠️ _Check economic calendar first_
🕐 `{sig['timestamp'].strftime('%d %b %Y  %H:%M')} IST`
""".strip()
        return msg

    async def send_signal(self, sig):
        return await self.send_message(self._format_signal(sig))

    async def send_no_signal(self, n=0):
        if n%6==0 and n>0:
            await self.send_message(
                f"⏳ *Scan #{n}* — No quality setup.\n"
                f"_ADX/OBV/Regime filters protecting your account._\n"
                f"🕐 `{datetime.now().strftime('%H:%M')} IST`")

    async def send_news_pause(self, nr):
        alerts="\n".join(nr["news"].get("alerts",[])[:3]) or "High-impact event"
        await self.send_message(
            f"🚨 *TRADING PAUSED*\n━━━━━━━━━━━━━━━━\n{alerts}\n\n"
            f"⛔ No signals until news passes.\n"
            f"🕐 `{datetime.now().strftime('%H:%M')} IST`")

    async def send_rule_block(self, reason):
        await self.send_message(f"🛑 *BLOCKED*\n━━━━━━━━━━━━\n{reason}")

    async def send_dashboard(self, d):
        pb =self._bar(d["profit_pct"])
        dlb=self._bar(d["daily_loss"]/d["daily_limit"]*100 if d["daily_limit"] else 0)
        tlb=self._bar(d["total_loss"]/d["total_limit"]*100 if d["total_limit"] else 0)
        await self.send_message(f"""
📊 *TRADEROOM DASHBOARD*
━━━━━━━━━━━━━━━━━━━━━━━
Stage: `{d['stage']}` | Balance: `${d['balance']:,}`
🎯 `{pb}` `{d['profit_pct']}%` — Need `${d['profit_needed']}`
{self._danger(d['daily_loss']/d['daily_limit']*100 if d['daily_limit'] else 0)} Daily: `{dlb}` `${d['daily_loss']}`/`$100`
{self._danger(d['total_loss']/d['total_limit']*100 if d['total_limit'] else 0)} Total: `{tlb}` `${d['total_loss']}`/`$200`
📅 Trading days: `{d['trading_days']}`
🕐 `{datetime.now().strftime('%d %b  %H:%M')} IST`
""".strip())

    async def send_journal_summary(self, journal):
        await self.send_message(journal.format_daily_summary())

    async def send_startup(self):
        # Extract information from the original message structure
        account_balance = "$5,000"
        mode = "SIGNAL ONLY"
        adx_filter = "✅"  # assuming active
        obv_confirmation = "✅" # assuming active
        fibonacci_zones = "✅" # assuming active
        candle_patterns = "✅" # assuming active
        market_regime = "✅" # assuming active
        three_tf_alignment = "✅" # assuming active
        funding_rate_active = "✅" # assuming active
        news_filter = "✅" # assuming active
        session_filter = "✅" # assuming active

        risk_per_trade = "$15/trade"
        daily_stop = "$80 daily stop"
        total_stop = "$160 total stop"
        min_rr = "1:3"
        min_confidence = "72%"
        win_rate_target = "55%+"

        timestamp = datetime.now().strftime("%d %b %Y  %H:%M:%S IST")

        msg = f"""
🚀 SIGNAL — GENERAL (BOT STATUS)
🟢 LONG or 🔴 SHORT based on direction

────────────────────────────────────────
ENTRY BLOCK:
Entry Zone: — → —
Stop Loss: —
Take Profit:
TP1: —
TP2: —
TP3: —

Risk/Reward: —

────────────────────────────────────────
MARKET CONFIRMATION:
ADX: {adx_filter} (ACTIVE)
OBV: {obv_confirmation}
FIB LEVEL: {fibonacci_zones}
CANDLE: {candle_patterns}
REGIME: {market_regime}
SESSION: {session_filter}

────────────────────────────────────────
RISK METRICS:
RSI: —
Volume: —x
Funding Rate: {funding_rate_active} ({three_tf_alignment})

────────────────────────────────────────
TRADE STATUS:
Stage: Bot Live
Confidence: {min_confidence}
Quality: —

────────────────────────────────────────
ACCOUNT STATUS:
Daily PnL: —%
Total PnL: —%
Trades Today: —

────────────────────────────────────────
REASONS (max 5 lines):
- Bot is live
- Monitoring market conditions
- Awaiting high-probability setups
- News filter active
- Session filter active

────────────────────────────────────────
FOOTER:
⚠️ Signal only — not financial advice
⚠️ Risk max per trade: {risk_per_trade}
🕐 Timestamp: {timestamp}
"""
        await self.send_message(msg)
